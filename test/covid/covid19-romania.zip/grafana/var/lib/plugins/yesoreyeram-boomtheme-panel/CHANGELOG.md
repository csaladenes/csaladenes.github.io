| Version | Changes                                                    |
| --------|------------------------------------------------------------|
| 0.1.0   | **First version for release**                              |
| 0.0.4   | Base theme option                                          |
|         | Bug fixes (#4)                                             |
| 0.0.3   | Schema changes  (BREAKING)                                 |
|         | Option to switch between default dark,light themes         | 
|         | BG Image as theme option                                   |
|         | Bug fixes                                                  |
| 0.0.2   | Multiple Themes, Theme picker                              |
| 0.0.1   | Base version                                               |