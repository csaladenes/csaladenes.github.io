import _ from "lodash";
describe("Default Test Suite", () => {
  it("Default Test 1", () => {
    expect("Hello").toBe("Hello");
  });
  it("Default Test 2", () => {
    expect(1).toBe(1);
  });
});
