# grafana-heatmap
[![Build Status](https://travis-ci.org/savantly-net/grafana-heatmap.svg?branch=master)](https://travis-ci.org/savantly-net/grafana-heatmap)

Heatmap Panel Plugin for Grafana

Example  
![Heatmap](https://raw.githubusercontent.com/savantly-net/grafana-heatmap/master/src/img/heatmap.PNG?raw=true)   

Color By Value grouped by timestamp  
![Timestamp Data](https://raw.githubusercontent.com/savantly-net/grafana-heatmap/master/src/img/timestamp_data.PNG?raw=true)  